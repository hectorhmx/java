public class Persona{
  String nombre;
  int edad;
  double estatura;
  double peso;
}
