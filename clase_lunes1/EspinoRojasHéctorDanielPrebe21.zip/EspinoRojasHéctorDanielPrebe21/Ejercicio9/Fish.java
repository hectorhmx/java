public class Fish extends Animal{
Fish(){
  super("Fish");
}
public String cantar(){
  return (name+" goes blub");
}
}
