public class Cat extends Animal{
Cat(){
  super("Cat");
}
public String cantar(){
  return (name+" goes meow");
}
}
