public class Bird extends Animal{
Bird(){
  super("Bird");
}
public String cantar(){
  return (name+" goes tweet");
}
}
