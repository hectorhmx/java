public class Dog extends Animal{
Dog(){
  super("Dog");
}
public String cantar(){
  return (name+" goes woof");
}
}
