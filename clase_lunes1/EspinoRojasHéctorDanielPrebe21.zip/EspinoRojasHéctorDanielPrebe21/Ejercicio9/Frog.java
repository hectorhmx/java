public class Frog extends Animal{
Frog(){
  super("Frog");
}
public String cantar(){
  return (name+" goes croak");
}
}
