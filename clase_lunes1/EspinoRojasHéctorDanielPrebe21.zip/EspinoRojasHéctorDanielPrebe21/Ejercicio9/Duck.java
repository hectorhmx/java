public class Duck extends Animal{
Duck(){
  super("Duck");
}
public String cantar(){
  return (name+"goes quak");
}
}
