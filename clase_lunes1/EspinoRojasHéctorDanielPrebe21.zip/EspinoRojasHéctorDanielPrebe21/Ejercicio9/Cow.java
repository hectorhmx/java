public class Cow extends Animal{
Cow(){
  super("Cow");
}
public String cantar(){
  return (name+" goes moo");
}
}
