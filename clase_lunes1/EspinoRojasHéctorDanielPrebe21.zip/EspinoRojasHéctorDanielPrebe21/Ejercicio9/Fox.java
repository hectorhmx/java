public class Fox extends Animal{
Fox(){
  super("Fox");
}
public String cantar(){
  return "What the fox say?\nwub-wid-bid-dum-way-do, wa-wa-way-do";
}
}
