public class Elephant extends Animal{
Elephant(){
  super("Elephant");
}
public String cantar(){
  return (name+" goes toot");
}
}
