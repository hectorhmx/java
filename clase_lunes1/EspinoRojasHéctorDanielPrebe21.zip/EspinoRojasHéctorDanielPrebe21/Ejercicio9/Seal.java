public class Seal extends Animal{
Seal(){
  super("Seal");
}
public String cantar(){
  return (name+" goes ow ow ow ");
}
}
