public class Mouse extends Animal{
Mouse(){
  super("Mouse");
}
public String cantar(){
  return (name+" goes squeek");
}
}
