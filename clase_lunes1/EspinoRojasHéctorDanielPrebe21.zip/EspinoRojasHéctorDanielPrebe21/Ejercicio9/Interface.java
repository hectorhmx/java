interface Interface{/**Se define una interfaz que tiene la fima del método cantar*/
  public String cantar();
}
