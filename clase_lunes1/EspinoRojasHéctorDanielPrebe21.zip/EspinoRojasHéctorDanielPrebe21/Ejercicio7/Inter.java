public interface Inter{/**Interfaz que da la firma de métodos abstractos*/
  public void tarea();
  public void dormir();
}
