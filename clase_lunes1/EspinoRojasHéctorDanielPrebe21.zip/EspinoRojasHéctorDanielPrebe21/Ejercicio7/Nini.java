public class Nini extends Alumno{

 Nini(String nombre,int edad, int materias){
   super(nombre,edad,materias);
 }
public void tarea(){
  System.out.println("Los ninis no hacen tarea");
}
}
